#Jestli je dané číslo palindrom --> vraťte nulu
"""
x = int(input("Zadejte čtyř-ciferné číslo: "))
c3 = x % 10
x = x // 10
c2 = x % 10
x = x // 10
c1 = x % 10
x = x // 10
c0 = x % 10
print(c3)
print(c2)
print(c1)
print(c0)
print(" ")
if c3 == c0 and c2 == c1:
    print(0)
else:
    print("Nejedná se o PALINDROM.")
"""
#Mějme trojciferné číslo. Chceme vrátit jeho jednotlivé cifry.
"""
random_number = 123
number_one = random_number % 10
first_number = random_number // 10
number_two = first_number % 10
second_number = first_number // 10
number_three = second_number % 10
print(number_three)
print(number_two)
print(number_one)
"""
#Uživatel zadá číslo (přirozené) a my chceme součet všech jeho čísel menších nebo rovno nule tomu n-přirozenému číslu.
"""
n = int(input("Zadej přirozené číslo: "))
adding_steps = 0
for i in range(n, 0, -1):
    adding_steps += i
print(adding_steps)
"""
#Program vráti nulu právě když je zadané číslo dělitelné 2, 3 a 5
"""
x = int(input("Zadejte číslo: "))

prvni_cislo = 2
druhe_cislo = 3
treti_cislo = 5

if (((x % prvni_cislo) == 0) and ((x % druhe_cislo) == 0) and ((x % treti_cislo) == 0)):
    print("YES BRO !!")
else:
    print("Eee-e")
"""
